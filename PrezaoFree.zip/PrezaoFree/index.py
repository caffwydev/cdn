import os
import pyautogui
pyautogui.FAILSAFE = False
pictures_folder = "pictures"
picture_files = os.listdir(pictures_folder)
print("Auto Prezão Free v1.0")
print("Banco de dados com", len(picture_files), "fotos")
print("Monitorando!")
while True:
  haystack = pyautogui.screenshot()
  for file in picture_files:
      pyautogui.moveTo(0, 100)
      try:
          image_path = os.path.join(pictures_folder, file)
          location = pyautogui.locateOnScreen(image_path, haystack)
          if location:
              pyautogui.click(location)
              print("AVISO: ", file.replace(".png", ""))
      except Exception as e:
        pass